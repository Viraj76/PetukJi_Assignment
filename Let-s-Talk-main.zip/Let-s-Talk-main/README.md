﻿# Let's-Talk
# App Link
https://drive.google.com/file/d/1DS5UD6LB7s_J5sasgnuCn7FP8_8w9CYC/view?usp=sharing

# Screen Shot
<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/0666513e-3292-4ed7-b8b0-00c21b3f7f81" width="250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/7134ee66-9587-4249-b0ae-08c1e5655f3e" width="250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/861439a5-ba14-4b12-965b-5813c5634437" width ="250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/a3f44ec9-e090-4d69-bf3a-d5e65c497529" width = "250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/69be9988-3eea-47ef-968c-38085c87b08b" width = "250">

<img src ="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/94129992-cd77-471e-9d35-87585dcd5bd5" width="250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/9cecc5e8-6575-4170-b7c3-cfb98866a008" width="250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/54765777-ee69-43d2-873a-71aad0c24e03" width = "250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/8087f366-a106-4452-b315-85a965578c2f" width ="250">

<img src="https://github.com/DevP-ai/Let-s-Talk/assets/107491760/8dd0228e-2d1b-442c-8026-c6bf4467a948" width="250">
