package com.tripod.fire.notification

data class NotificationData(
    val title:String?="",
    val message:String?=""
)
